'use client';

/**
 * Thin wrapper around localStorage for local-only game data (profile,
 * inventory, settings). No backend/Firebase in this phase — everything
 * lives on-device. Every call is guarded so it never throws inside the
 * Android WebView (private-browsing-style contexts can restrict storage).
 */
export function getItem<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function setItem<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // storage full/unavailable — fail silently, game keeps running
  }
}

export function removeItem(key: string): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.removeItem(key);
  } catch {
    // ignore
  }
}
