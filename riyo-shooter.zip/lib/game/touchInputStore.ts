'use client';

import { useRef, useSyncExternalStore } from 'react';

export interface TouchInputState {
  moveX: number; // -1..1 from virtual joystick
  moveY: number; // -1..1 from virtual joystick
  looking: boolean;
  lookDX: number; // drag delta since last read, right-side touch area
  lookDY: number;
  firing: boolean;
}

/**
 * Minimal external store (no extra dependency) shared between the HTML
 * touch-control overlay and the R3F scene, so joystick/fire-button input
 * from components/game/TouchControls reaches components/game/PlayerRig
 * every frame without prop-drilling through the Canvas tree.
 */
const state: TouchInputState = {
  moveX: 0,
  moveY: 0,
  looking: false,
  lookDX: 0,
  lookDY: 0,
  firing: false,
};

const listeners = new Set<() => void>();

export function setTouchInput(partial: Partial<TouchInputState>) {
  Object.assign(state, partial);
  listeners.forEach((l) => l());
}

export function consumeLookDelta(): { dx: number; dy: number } {
  const dx = state.lookDX;
  const dy = state.lookDY;
  state.lookDX = 0;
  state.lookDY = 0;
  return { dx, dy };
}

export function useTouchInputStore(): TouchInputState {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => state
  );
}
