import type { Weapon } from '@/types';

/**
 * Static weapon catalog. Kept as plain data (not hardcoded branching logic)
 * so new weapons can be added without touching component code.
 */
export const WEAPONS: Weapon[] = [
  { id: 'pistol', name: 'Pistol', damage: 12, fireRateMs: 260, ammoCapacity: 12, iconKey: 'pistol' },
  { id: 'smg', name: 'SMG', damage: 8, fireRateMs: 90, ammoCapacity: 30, iconKey: 'smg' },
  { id: 'rifle', name: 'Assault Rifle', damage: 18, fireRateMs: 130, ammoCapacity: 25, iconKey: 'rifle' },
  { id: 'shotgun', name: 'Shotgun', damage: 45, fireRateMs: 700, ammoCapacity: 6, iconKey: 'shotgun' },
];

export function getWeaponById(id: string): Weapon | undefined {
  return WEAPONS.find((w) => w.id === id);
}
