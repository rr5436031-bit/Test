'use client';

/**
 * Locks the native screen orientation to landscape and enables an
 * edge-to-edge immersive layout. No-ops gracefully on plain web/dev
 * where the Capacitor plugins aren't present, so `npm run dev` in a
 * desktop browser still works for iterating on UI.
 */
export async function lockToLandscapeAndImmersive() {
  if (typeof window === 'undefined') return;

  try {
    const { ScreenOrientation } = await import('@capacitor/screen-orientation');
    await ScreenOrientation.lock({ orientation: 'landscape' });
  } catch {
    // Not running inside Capacitor (e.g. `npm run dev` in a browser) — ignore.
  }

  try {
    const { StatusBar } = await import('@capacitor/status-bar');
    await StatusBar.hide();
  } catch {
    // Not running inside Capacitor — ignore.
  }
}
