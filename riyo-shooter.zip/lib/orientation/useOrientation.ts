'use client';

import { useEffect, useState } from 'react';

/**
 * Reports whether the device is currently in landscape orientation.
 * Used purely for the "PUTAR PERANGKAT" gate in the UI layer — the actual
 * orientation LOCK is enforced natively via Capacitor (see
 * lib/orientation/lockOrientation.ts), because CSS alone cannot stop the
 * WebView from rotating the surface on some Android skins.
 */
export function useIsLandscape(): boolean {
  const [isLandscape, setIsLandscape] = useState(true);

  useEffect(() => {
    const check = () => {
      setIsLandscape(window.innerWidth > window.innerHeight);
    };
    check();
    window.addEventListener('resize', check);
    window.addEventListener('orientationchange', check);
    return () => {
      window.removeEventListener('resize', check);
      window.removeEventListener('orientationchange', check);
    };
  }, []);

  return isLandscape;
}
