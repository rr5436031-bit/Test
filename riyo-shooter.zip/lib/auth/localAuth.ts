'use client';

import { getItem, setItem } from '@/lib/storage/localStore';
import type { PlayerProfile } from '@/types';

const PROFILE_KEY = 'riyo-shooter:profile';

/**
 * Placeholder local "auth" for phase one: a device-local profile with no
 * real account system, no Google OAuth, no backend. Swap this module out
 * later without touching UI code once real auth is introduced.
 */
export function getLocalProfile(): PlayerProfile {
  return getItem<PlayerProfile>(PROFILE_KEY, {
    id: 'local-player',
    name: 'Pemain',
    level: 1,
    xp: 0,
    coins: 0,
  });
}

export function saveLocalProfile(profile: PlayerProfile): void {
  setItem(PROFILE_KEY, profile);
}
