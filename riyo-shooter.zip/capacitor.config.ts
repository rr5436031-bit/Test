import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.riyogame.shooter',
  appName: 'Riyo Shooter',
  webDir: 'out',
  // No local server dependency: the APK loads files bundled from out/ directly.
  server: {
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: false,
  },
  plugins: {
    StatusBar: {
      overlaysWebView: true,
      style: 'DARK',
    },
    SplashScreen: {
      launchShowDuration: 0, // we render our own in-app splash instead
    },
  },
};

export default config;
