'use client';

import { useRouter } from 'next/navigation';
import { Swords, Backpack, User, Play } from 'lucide-react';
import { motion } from 'framer-motion';

/**
 * Main menu. No scroll (fits one landscape screen), no server calls —
 * all data comes from local profile/inventory via lib/storage.
 */
export default function LobbyScreen() {
  const router = useRouter();

  return (
    <div className="fixed inset-0 flex flex-col justify-between bg-background text-white safe-area no-select overflow-hidden">
      <header className="px-6 pt-4">
        <h1 className="text-2xl font-bold tracking-wide">RIYO SHOOTER</h1>
      </header>

      <div className="flex-1 flex items-center justify-center">
        <motion.button
          whileTap={{ scale: 0.94 }}
          onClick={() => router.push('/game/')}
          className="flex items-center gap-3 rounded-2xl bg-red-600 px-10 py-4 text-lg font-bold shadow-lg shadow-red-600/30"
        >
          <Play size={22} /> MAIN
        </motion.button>
      </div>

      <nav className="flex justify-center gap-6 pb-6">
        <LobbyNavButton icon={<Swords size={20} />} label="Senjata" onClick={() => {}} />
        <LobbyNavButton icon={<Backpack size={20} />} label="Inventori" onClick={() => {}} />
        <LobbyNavButton icon={<User size={20} />} label="Profil" onClick={() => {}} />
      </nav>
    </div>
  );
}

function LobbyNavButton({
  icon,
  label,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      className="flex flex-col items-center gap-1 rounded-xl bg-white/5 px-5 py-2 text-white/80"
    >
      {icon}
      <span className="text-xs">{label}</span>
    </motion.button>
  );
}
