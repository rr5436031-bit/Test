'use client';

import { useEffect } from 'react';
import { useIsLandscape } from '@/lib/orientation/useOrientation';
import { lockToLandscapeAndImmersive } from '@/lib/orientation/lockOrientation';

/**
 * Wraps the whole app. Attempts a native landscape lock on mount (so a
 * real Android build never rotates), and shows a "PUTAR PERANGKAT" gate
 * as a CSS-level fallback for the split second before the native lock
 * applies, or in a plain browser where no native lock exists.
 */
export default function OrientationGate({ children }: { children: React.ReactNode }) {
  const isLandscape = useIsLandscape();

  useEffect(() => {
    lockToLandscapeAndImmersive();
  }, []);

  if (!isLandscape) {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center bg-background text-white gap-4 no-select">
        <div className="text-5xl animate-pulse">⟳</div>
        <p className="text-lg font-semibold tracking-wide">PUTAR PERANGKAT</p>
        <p className="text-sm text-white/60">Riyo Shooter membutuhkan mode landscape</p>
      </div>
    );
  }

  return <>{children}</>;
}
