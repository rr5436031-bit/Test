'use client';

import { useEffect, useState } from 'react';

/**
 * Loading/splash screen. Background image should be placed at
 * public/images/splash.jpg (fullscreen landscape artwork). Swap the path
 * below once the real splash art is dropped into public/images/.
 */
export default function SplashScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const start = Date.now();
    const duration = 1400;
    let raf: number;
    const tick = () => {
      const pct = Math.min(100, ((Date.now() - start) / duration) * 100);
      setProgress(pct);
      if (pct < 100) {
        raf = requestAnimationFrame(tick);
      } else {
        onDone();
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  return (
    <div
      className="fixed inset-0 no-select"
      style={{
        backgroundImage: "url('/images/splash.jpg')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundColor: '#0a0a0f', // fallback while splash.jpg is not yet supplied
      }}
    >
      <div className="absolute inset-0 bg-black/30 flex flex-col justify-end pb-10 safe-area">
        <div className="mx-8 h-2 rounded-full bg-white/20 overflow-hidden">
          <div
            className="h-full bg-white transition-[width] duration-75"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="mx-8 mt-2 text-xs text-white/70">Memuat... {Math.floor(progress)}%</p>
      </div>
    </div>
  );
}
