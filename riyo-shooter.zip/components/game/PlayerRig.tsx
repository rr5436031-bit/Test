'use client';

import { useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { consumeLookDelta, type TouchInputState } from '@/lib/game/touchInputStore';

const MOVE_SPEED = 4; // meters/sec
const LOOK_SENSITIVITY = 0.0025;

/**
 * First-person rig: moves the camera on the XZ plane from the virtual
 * joystick, and yaw/pitch-rotates it from right-side drag deltas. Fire
 * input is read here too (stubbed — wire into lib/game/weapons + a
 * projectile/hit system next).
 */
export default function PlayerRig({ input }: { input: TouchInputState }) {
  const { camera } = useThree();
  const yaw = useRef(0);
  const pitch = useRef(0);
  const lastFireAt = useRef(0);

  useFrame((_, delta) => {
    const { dx, dy } = consumeLookDelta();
    yaw.current -= dx * LOOK_SENSITIVITY;
    pitch.current = THREE.MathUtils.clamp(
      pitch.current - dy * LOOK_SENSITIVITY,
      -Math.PI / 2.5,
      Math.PI / 2.5
    );
    camera.rotation.order = 'YXZ';
    camera.rotation.set(pitch.current, yaw.current, 0);

    const forward = new THREE.Vector3(Math.sin(yaw.current), 0, Math.cos(yaw.current));
    const right = new THREE.Vector3(forward.z, 0, -forward.x);

    const move = new THREE.Vector3()
      .addScaledVector(forward, -input.moveY)
      .addScaledVector(right, input.moveX);

    if (move.lengthSq() > 0) {
      move.normalize().multiplyScalar(MOVE_SPEED * delta);
      camera.position.add(move);
      camera.position.y = 1.6; // fixed eye height, no gravity/jump yet
    }

    if (input.firing) {
      const now = performance.now();
      if (now - lastFireAt.current > 150) {
        lastFireAt.current = now;
        // TODO: spawn projectile / raycast hit using lib/game/weapons catalog
      }
    }
  });

  return null;
}
