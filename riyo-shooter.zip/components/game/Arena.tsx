'use client';

/**
 * Minimal placeholder arena geometry. Swap for a real level/GLTF later —
 * kept as simple primitives so the project builds with zero external
 * model assets out of the box.
 */
export default function Arena() {
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[60, 60]} />
        <meshStandardMaterial color="#1c1c24" />
      </mesh>

      {[...Array(8)].map((_, i) => (
        <mesh key={i} position={[(i - 4) * 6, 1, -6]}>
          <boxGeometry args={[1.5, 2, 1.5]} />
          <meshStandardMaterial color="#3a3a46" />
        </mesh>
      ))}
    </group>
  );
}
