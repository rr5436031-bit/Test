'use client';

import { useRef } from 'react';
import { setTouchInput } from '@/lib/game/touchInputStore';

/**
 * Virtual joystick (left) + fire button (right), and a drag-to-look zone
 * across the right half of the screen. Pure HTML/pointer-events overlay —
 * deliberately NOT inside the <Canvas> so it keeps working regardless of
 * WebGL context state, and uses pointer events (not mouse events) so it
 * behaves correctly on Android WebView touch input.
 */
export default function TouchControls() {
  const joystickOrigin = useRef<{ x: number; y: number } | null>(null);
  const lookOrigin = useRef<{ x: number; y: number } | null>(null);

  const onJoystickStart = (e: React.PointerEvent) => {
    joystickOrigin.current = { x: e.clientX, y: e.clientY };
  };
  const onJoystickMove = (e: React.PointerEvent) => {
    if (!joystickOrigin.current) return;
    const dx = e.clientX - joystickOrigin.current.x;
    const dy = e.clientY - joystickOrigin.current.y;
    const max = 50;
    setTouchInput({
      moveX: Math.max(-1, Math.min(1, dx / max)),
      moveY: Math.max(-1, Math.min(1, dy / max)),
    });
  };
  const onJoystickEnd = () => {
    joystickOrigin.current = null;
    setTouchInput({ moveX: 0, moveY: 0 });
  };

  const onLookStart = (e: React.PointerEvent) => {
    lookOrigin.current = { x: e.clientX, y: e.clientY };
    setTouchInput({ looking: true });
  };
  const onLookMove = (e: React.PointerEvent) => {
    if (!lookOrigin.current) return;
    const dx = e.clientX - lookOrigin.current.x;
    const dy = e.clientY - lookOrigin.current.y;
    lookOrigin.current = { x: e.clientX, y: e.clientY };
    setTouchInput({ lookDX: dx, lookDY: dy });
  };
  const onLookEnd = () => {
    lookOrigin.current = null;
    setTouchInput({ looking: false });
  };

  return (
    <div className="absolute inset-0 select-none">
      {/* left half: movement joystick */}
      <div
        className="absolute left-0 top-0 h-full w-1/2"
        onPointerDown={onJoystickStart}
        onPointerMove={onJoystickMove}
        onPointerUp={onJoystickEnd}
        onPointerCancel={onJoystickEnd}
      >
        <div className="absolute bottom-10 left-10 h-24 w-24 rounded-full border-2 border-white/40" />
      </div>

      {/* right half: drag to look */}
      <div
        className="absolute right-0 top-0 h-full w-1/2"
        onPointerDown={onLookStart}
        onPointerMove={onLookMove}
        onPointerUp={onLookEnd}
        onPointerCancel={onLookEnd}
      >
        <button
          className="absolute bottom-10 right-10 h-20 w-20 rounded-full bg-red-600/80 text-white font-bold text-sm active:scale-90 transition-transform"
          onPointerDown={(e) => {
            e.stopPropagation();
            setTouchInput({ firing: true });
          }}
          onPointerUp={(e) => {
            e.stopPropagation();
            setTouchInput({ firing: false });
          }}
          onPointerCancel={() => setTouchInput({ firing: false })}
        >
          FIRE
        </button>
      </div>
    </div>
  );
}
