'use client';

import { Canvas } from '@react-three/fiber';
import { Suspense } from 'react';
import PlayerRig from './PlayerRig';
import Arena from './Arena';
import TouchControls from './TouchControls';
import { useTouchInputStore } from '@/lib/game/touchInputStore';

/**
 * Root of the 3D gameplay screen. dpr capped for WebView GPU budgets;
 * no postprocessing in phase one to keep frame time predictable on
 * mid-range Android hardware.
 */
export default function GameCanvas() {
  const input = useTouchInputStore();

  return (
    <div className="fixed inset-0 bg-black no-select overflow-hidden">
      <Canvas
        dpr={[1, 1.5]}
        camera={{ fov: 70, position: [0, 1.6, 4] }}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.6} />
          <directionalLight position={[5, 10, 5]} intensity={1.2} castShadow={false} />
          <Arena />
          <PlayerRig input={input} />
        </Suspense>
      </Canvas>

      {/* HTML overlay: virtual joystick + fire button, independent of the
         WebGL canvas so touch handling stays reliable on Android WebView */}
      <TouchControls />
    </div>
  );
}
