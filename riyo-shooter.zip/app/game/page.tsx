'use client';

import OrientationGate from '@/components/ui/OrientationGate';
import GameCanvas from '@/components/game/GameCanvas';

export default function GamePage() {
  return (
    <OrientationGate>
      <GameCanvas />
    </OrientationGate>
  );
}
