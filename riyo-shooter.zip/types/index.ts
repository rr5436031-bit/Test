export interface PlayerProfile {
  id: string;
  name: string;
  level: number;
  xp: number;
  coins: number;
}

export interface Weapon {
  id: string;
  name: string;
  damage: number;
  fireRateMs: number;
  ammoCapacity: number;
  iconKey: string;
}

export interface InventoryItem {
  weaponId: string;
  owned: boolean;
  equipped: boolean;
}

export type GameScreen = 'splash' | 'lobby' | 'inventory' | 'profile' | 'game';
